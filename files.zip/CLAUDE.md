# ReelTune — AI Context & Rules File

## What Is This App
ReelTune is a cross-platform music discovery and playlist management app.
Core user flow:
Instagram Reel → Share to ReelTune → Song identified → Saved to library → Organized into playlists → Synced to Spotify/YouTube

One-sentence definition: ReelTune lets users save songs they discover on Instagram Reels, automatically identifies them, organizes them into playlists, and syncs those playlists to Spotify and YouTube.

---

## Monorepo Structure (always follow this)
```
reeltune/
├── apps/
│   ├── mobile/        # React Native + Expo + Expo Router
│   ├── web/           # Next.js + Tailwind (lightweight companion)
│   └── api/           # NestJS backend
├── packages/
│   ├── types/         # Shared TypeScript types — used by all apps
│   ├── config/        # Shared config (eslint, tsconfig bases)
│   └── utils/         # Shared utility functions
├── package.json
└── pnpm-workspace.yaml
```

---

## Tech Stack (non-negotiable — do not suggest alternatives)
| Layer           | Technology                          |
|-----------------|-------------------------------------|
| Mobile          | React Native + Expo + Expo Router   |
| Styling (mobile)| NativeWind (Tailwind for RN)        |
| State           | Zustand (app state)                 |
| Server state    | TanStack Query                      |
| Web             | Next.js + Tailwind CSS              |
| Backend         | NestJS (TypeScript)                 |
| ORM             | Prisma                              |
| Database        | PostgreSQL                          |
| Auth            | Supabase Auth                       |
| Cache           | Redis                               |
| Jobs            | BullMQ + Redis                      |
| Music metadata  | Spotify Web API                     |
| YouTube         | YouTube Data API v3                 |
| Recognition     | Dedicated recognition service (AudD or ACRCloud) |
| Storage         | Supabase Storage                    |
| Deployment      | Railway (API + DB + Redis) + Expo EAS (mobile) |
| Monitoring      | Sentry (errors) + PostHog (analytics) |
| Package manager | pnpm                                |

---

## Language Rules
- TypeScript EVERYWHERE. No .js files in this project.
- `strict: true` in all tsconfig.json files.
- Shared types always live in `packages/types` — never duplicate them in individual apps.
- Import shared types as `@reeltune/types`.

---

## Naming Conventions
| Thing                  | Convention              | Example              |
|------------------------|-------------------------|----------------------|
| Files                  | kebab-case              | `song-card.tsx`      |
| React components       | PascalCase              | `SongCard`           |
| Functions & variables  | camelCase               | `savedSongs`         |
| Database tables        | snake_case              | `saved_songs`        |
| API routes             | /api/v1/kebab-case      | `/api/v1/playlists`  |
| Prisma models          | PascalCase singular     | `Song`, `SavedSong`  |
| NestJS files           | feature.type.ts         | `songs.service.ts`   |
| Env variables          | SCREAMING_SNAKE_CASE    | `SPOTIFY_CLIENT_ID`  |

---

## Design System (never deviate)

### Colors
```
Primary background:   #080706   (almost-black warm)
Secondary background: #11100E
Card:                 #181512
Elevated card:        #211B16
Primary accent:       #D99A5B   (warm caramel/orange — ReelTune's brand color)
Accent highlight:     #F0C28F
Primary text:         #F5F1EB
Secondary text:       #A9A29A
Muted text:           #6F6A64
Success:              #8FBF9A
Error:                #D77A70
```
Spotify/YouTube keep their own brand colors ONLY when representing those integrations.

### Typography
Font: **Manrope** (import from Google Fonts)
```
Display:  42px / Bold
H1:       32px / Bold
H2:       24px / Semibold
H3:       18px / Semibold
Body:     15px / Regular
Small:    13px / Medium
Caption:  11px / Medium
```

### Spacing (8px base)
Use: 4, 8, 12, 16, 24, 32, 40, 48, 64

### Border Radius
```
Buttons:       14px
Cards:         20px
Artwork:       16px
Bottom sheets: 28px
Inputs:        14px
```

### Icons
Use **Lucide Icons only** (outline style). Never mix icon libraries.
Approved icons: Search, Heart, Plus, Music, MoreHorizontal, Play, Share2, Link, Check, Settings, User, ChevronRight

### Reusable Components (build these, don't redesign per screen)
Button, IconButton, SongCard, SongRow, AlbumArtwork, PlaylistCard,
PlaylistHeader, SearchBar, BottomSheet, Modal, Toast, ProgressBar,
ServiceButton, TabBar, NavigationBar, EmptyState, LoadingState, AudioWave

---

## NestJS Backend Architecture
```
apps/api/src/
├── auth/
├── users/
├── songs/
├── playlists/
├── recognition/
├── integrations/
│   ├── spotify/
│   └── youtube/
├── sync/
├── notifications/
└── common/
    ├── guards/
    ├── decorators/
    ├── filters/
    └── interceptors/
```
- Business logic lives in **Services**, not Controllers.
- Use NestJS DTOs + class-validator for all request validation.
- Use NestJS Guards for auth protection on every private route.
- Never put external API calls in Controllers.

---

## Mobile Navigation
5-tab bottom nav: **Home | Search | + (Save) | Library | Profile**
The central + button is the most important action in the app — style it prominently.

### Expo Router Screens
```
/                    → Home
/search              → Search
/save                → Save from Reel (central CTA)
/library             → Saved Songs
/library/[id]        → Song Details
/playlists           → Playlist List
/playlists/[id]      → Playlist Details
/playlists/create    → Create Playlist
/profile             → Profile & Settings
/settings/spotify    → Spotify Connection
/settings/youtube    → YouTube Connection
/recognize           → Song Recognition flow
/sync/[jobId]        → Sync Progress
```

---

## Data Architecture (critical — do not violate)

### Internal Song Object (canonical entity)
```typescript
{
  id: string           // ReelTune internal ID — the source of truth
  title: string
  artists: string[]
  album: string
  artwork: string
  duration: number
  isrc: string | null  // industry standard cross-platform ID
  spotifyId: string | null
  youtubeId: string | null
  metadata: JSON
}
```
**NEVER make Spotify the source of truth.** The internal Song is always canonical.
Playlists are platform-agnostic — sync creates a copy on Spotify/YouTube, it doesn't move the data.

---

## Instagram Integration Rules
- NEVER assume Instagram provides unrestricted API access to Reel audio.
- Always support ALL 4 ingestion methods:
  1. Share Reel → ReelTune (primary)
  2. Paste Reel URL (fallback)
  3. Manual song search (always available)
  4. Audio upload/recording (stretch)
- Recognition is a **separate decoupled service** — output is always `{ title, artist, confidence }`.
- Always display confidence score to user. Never pretend identification is certain.
- If confidence < 70%: show top 3 candidates and offer manual search.

---

## Playlist Sync Rules
- ALL sync operations are async via BullMQ queue — never synchronous.
- Return `jobId` immediately from the API; client polls `/api/v1/sync/:jobId` for progress.
- Never block an HTTP request while processing songs.
- Sync result must always show: matched count, skipped count, unavailable count.

---

## API Design Rules
- All routes: `/api/v1/resource`
- Auth: JWT bearer token on all protected routes
- Never expose Spotify/YouTube tokens to the frontend — backend holds them
- Rate limit all endpoints (especially recognition and search)
- Every error returns: `{ statusCode, message, error }` — never silently fail

### API Surface (reference)
```
POST /api/v1/auth/register
POST /api/v1/auth/login
GET  /api/v1/auth/me

GET  /api/v1/songs/search?q=
GET  /api/v1/songs/:id
POST /api/v1/songs/save
DELETE /api/v1/songs/:id/save
GET  /api/v1/users/me/songs

POST /api/v1/recognition/instagram
POST /api/v1/recognition/audio

GET    /api/v1/playlists
POST   /api/v1/playlists
GET    /api/v1/playlists/:id
PATCH  /api/v1/playlists/:id
DELETE /api/v1/playlists/:id
POST   /api/v1/playlists/:id/songs
DELETE /api/v1/playlists/:id/songs/:songId
PATCH  /api/v1/playlists/:id/reorder

GET /api/v1/integrations/spotify/connect
GET /api/v1/integrations/spotify/callback
GET /api/v1/integrations/youtube/connect
GET /api/v1/integrations/youtube/callback

POST /api/v1/playlists/:id/sync/spotify
POST /api/v1/playlists/:id/sync/youtube
GET  /api/v1/sync/:jobId
```

---

## Security Rules (never break)
- NEVER store Spotify/YouTube refresh tokens on the client (mobile or web).
- NEVER commit `.env` files.
- NEVER put API keys in source code.
- Hash passwords with Argon2.
- Use Supabase Auth for user auth — don't roll your own JWT from scratch.
- Encrypt OAuth tokens at rest.
- CORS: whitelist allowed origins explicitly.
- Input validation on every endpoint via class-validator DTOs.

---

## Error Handling Patterns (always follow)
Every error state must have a recovery action shown to the user.
```
Song identification failed  → [Try Again] [Paste Reel URL] [Search Song]
Spotify connection failed   → [Reconnect Spotify] [Try Again]
Song unavailable on Spotify → [Search Manually] [Skip]
Playlist sync partial fail  → Show matched/skipped/unavailable counts with [View Results]
```
Never use generic "Something went wrong" without an action the user can take.

---

## PostHog Analytics Events (instrument these)
```
song_saved              { source: 'instagram' | 'search' | 'url' | 'audio' }
song_identification_success { confidence: number }
song_identification_failed
playlist_created
spotify_connected
youtube_connected
playlist_synced         { total, matched, skipped, unavailable }
```

---

## DO NOT
- Write `.js` files — TypeScript only
- Add new colors outside the design system
- Use a different icon library
- Duplicate shared types — import from `@reeltune/types`
- Put business logic in NestJS controllers
- Call Spotify/YouTube APIs from the mobile app directly
- Do sync operations synchronously (always use BullMQ)
- Design around only the Instagram share mechanism — always build fallbacks
- Make Spotify the source of truth for Song data
- Turn the app into a streaming service — it is a discovery/organization/sync layer only
