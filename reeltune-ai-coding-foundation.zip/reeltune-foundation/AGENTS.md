# ReelTune AI Coding Rules

## Product
ReelTune turns music discovered on Instagram Reels into organized playlists and syncs them to Spotify/YouTube. Core flow: Reel -> identify -> save -> playlist -> sync.

## Stack
- Mobile: React Native + Expo + Expo Router + TypeScript
- Styling: NativeWind
- Client state: Zustand; server state: TanStack Query
- API: NestJS REST + TypeScript
- DB: PostgreSQL + Prisma
- Auth: Supabase Auth
- Cache/jobs: Redis + BullMQ
- Storage: Supabase Storage
- Integrations: Spotify Web API; YouTube Data API
- Web: Next.js + Tailwind
- Validation: Zod on clients/shared boundaries; class-validator or Zod consistently in API
- Tests: Vitest/Jest + Supertest; E2E with Playwright/Detox as introduced
- Tooling: pnpm, ESLint, Prettier, strict TypeScript
- Deploy: Vercel (web), Railway (API/worker), Expo EAS (mobile)

## Repository
apps/mobile, apps/web, apps/api, packages/types, packages/config, packages/utils, docs, scripts

## Rules
1. Read AGENTS.md, docs/PLAN.md, docs/DATA_MODEL.md, and docs/API_CONTRACTS.md before coding.
2. One task at a time. Do not implement future tasks unless required by the current task.
3. Plan first, then code, then test, then report the diff.
4. Preserve the existing architecture and naming conventions.
5. Never put secrets in source code, prompts, commits, logs, screenshots, or tests.
6. Never commit .env files. Update .env.example when adding configuration.
7. Never treat Spotify or YouTube as the source of truth. Internal Song IDs are canonical.
8. Never assume Instagram exposes unrestricted Reel audio/metadata. Use supported share/URL/manual/recognition paths.
9. Never scrape Instagram aggressively or bypass access controls.
10. Never store raw third-party OAuth tokens in logs.
11. Validate external API responses and use timeouts, retries, and rate limits.
12. Avoid destructive DB changes without an explicit migration plan.
13. Prefer small reusable functions over giant components/services.
14. Do not silently change API response shapes. Update API_CONTRACTS and tests first.
15. Every feature task must add/update tests for its acceptance criteria.
16. Run lint, typecheck, unit tests, and relevant integration tests before declaring a task done.
17. Keep UI faithful to docs/DESIGN_SYSTEM.md; do not invent a new visual language.
18. Use platform-independent Song entities with spotifyId, youtubeId, and isrc when available.
19. Sync operations must be idempotent and record per-track results.
20. For uncertainty, stop and state the assumption instead of inventing behavior.

## Definition of Done
- Acceptance criteria pass.
- Tests added/updated and passing.
- Typecheck passes.
- Lint/format passes.
- No secrets or debug logging committed.
- API/schema docs updated if contracts changed.
- Migration included if DB changed.
- Commit is focused and describes the task.
